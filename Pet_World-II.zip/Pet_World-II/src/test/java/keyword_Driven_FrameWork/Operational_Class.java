package keyword_Driven_FrameWork;

import java.time.Duration;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Operational_Class {

	public void url(WebDriver driver) 
	{
		driver.get("https://petsworld.in/");
	}
	public void maximize(WebDriver driver) 
	{
		driver.manage().window().maximize();
	}
	public void cookies(WebDriver driver) 
	{
		driver.manage().deleteAllCookies();
	}
	public void loginButton(WebDriver driver) throws Exception 
	{
		driver.findElement(By.xpath("//span[text()='Login']")).click();
		Thread.sleep(2000);
	}
	public void EnterEmail(WebDriver driver) throws Exception 
	{
		driver.findElement(By.xpath("//input[@placeholder='Mobile Number / Email']")).sendKeys("kumaripuja2359@gmail.com");
		Thread.sleep(2000);
	}
	public void ClickOnContinue(WebDriver driver) throws Exception 
	{
		driver.findElement(By.xpath("//div[@class='flex-1 flex items-center justify-center']")).click();
		Thread.sleep(2000);
	}
	public void ClickOnSendOTP(WebDriver driver) throws Exception 
	{
		driver.findElement(By.xpath("//div[@class='flex-1 flex items-center justify-center']")).click();
		Thread.sleep(2000);
		String D1 = JOptionPane.showInputDialog("BOX 1");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[1]/div/section/div[2]/div[1]/div/div[1]/div[1]/input"))
				.sendKeys(D1);
		Thread.sleep(2000);
		String D2 = JOptionPane.showInputDialog("BOX 2");
		driver.findElement(By.xpath("//input[@aria-label='Digit 2']")).sendKeys(D2);
		Thread.sleep(2000);
		String D3 = JOptionPane.showInputDialog("BOX 3");
		driver.findElement(By.xpath("//input[@aria-label='Digit 3']")).sendKeys(D3);
		Thread.sleep(2000);
		String D4 = JOptionPane.showInputDialog("BOX 4");
		driver.findElement(By.xpath("//input[@aria-label='Digit 4']")).sendKeys(D4);
		Thread.sleep(2000);
		String D5 = JOptionPane.showInputDialog("BOX 5");
		driver.findElement(By.xpath("//input[@aria-label='Digit 5']")).sendKeys(D5);
		Thread.sleep(2000);
		String D6 = JOptionPane.showInputDialog("BOX 6");
		driver.findElement(By.xpath("//input[@aria-label='Digit 6']")).sendKeys(D6);
		Thread.sleep(2000);
	}
	public void ClickOnVerify(WebDriver driver) throws Exception 
	{
		driver.findElement(By.xpath("//div[contains(text(),'Verify')]")).click();
	}

	public void logoutButton(WebDriver driver) throws Exception 
	{
		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement myaccount= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[3]/div[3]/a[1]/span[1]")));		
		
	   // WebElement myaccount = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[3]/div[3]/a[1]/span[1]"));
		Actions a1 = new Actions(driver);   
		a1.moveToElement(myaccount).perform(); // hover on my account
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[3]/div[3]/div[1]/ul[1]/li[3]")).click();
	}
}
