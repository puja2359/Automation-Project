package keyword_Driven_FrameWork;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Main_Class 
{

	public static void main(String[] args) throws Exception 
	{
		WebDriver driver;
        WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		Thread.sleep(2000);

		ReadExcel_Class a = new ReadExcel_Class();
		a.readexcel(driver);
    }

}