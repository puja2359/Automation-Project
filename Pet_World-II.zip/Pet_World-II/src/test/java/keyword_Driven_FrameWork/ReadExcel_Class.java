package keyword_Driven_FrameWork;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class ReadExcel_Class 
{
		public void readexcel(WebDriver  driver) throws Exception
		{
			//ExcelSheet
				FileInputStream file=new FileInputStream("C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\POI\\New_PetsWorld_POI.xlsx");
				
				XSSFWorkbook w= new XSSFWorkbook(file);
				
				XSSFSheet s= w.getSheet("Pets_KDT");
				
				int rowSize= s.getLastRowNum();
				System.out.println("No of Keywords: "+ rowSize );
				
				Operational_Class l= new Operational_Class();
				   for(int i=1; i<rowSize; i++)
				   {
					 String Key= s.getRow(i).getCell(0).getStringCellValue();
					 System.out.println("Key");
					 
					    if(Key.equals("OpenApplication"))
					    {
					    	l.url(driver);
					    	l.maximize(driver);
					        l.cookies(driver);
					    	Thread.sleep(2000);
					    }
					    else if (Key.equals("ClickOnLoginButton"))
					    {
					    	l.loginButton(driver);				    }
					    else if(Key.equals("EnterEmail"))
					    {
					    	l.EnterEmail(driver);
					    }
					    else if(Key.equals("ClickOnContinue"))
					    {
					    	l.ClickOnContinue(driver);
					    	Thread.sleep(2000);
					    }
					    else if(Key.equals("ClickOnSendOTP"))
					    {
					    	l.ClickOnSendOTP(driver);
					    }
					    else if(Key.equals("ClickOnVerify"))
					    {
					    	l.ClickOnVerify(driver);
					    	Thread.sleep(2000);
					    }		 
					    else if(Key.equals("ClickOnLogoutButton"))
					    {
					    	l.logoutButton(driver);
					    	Thread.sleep(2000);
					    }
					    else if(Key.equals("CloseBrowser"))
					    {
					    	driver.close();
					    }
				   }
      }
}
