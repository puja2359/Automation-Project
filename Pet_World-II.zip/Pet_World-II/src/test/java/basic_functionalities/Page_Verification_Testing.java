package basic_functionalities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Page_Verification_Testing {
	WebDriver driver;

	@BeforeTest
	public void before() {

		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

	}

	@Test
	public void pageverification() {
		String title = driver.getTitle();
		System.out.println("Page title is:" + title);

		String expectedTitle = "Online Pet Shop & Supplies Store - Buy Pet Food & Accessories";

		if (title.equals(expectedTitle)) {
			System.out.println("Test Passed!");
		} else {
			System.out.println("Test Failed");
		}
        driver.close();
	}

}
