package basic_functionalities;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorld_POM;

public class Cross_Browser_Testing {
	public void url(WebDriver driver) {
		driver.get("https://petsworld.in/");
	}

	public void maximize(WebDriver driver) {
		driver.manage().window().maximize();
	}

	public void cookies(WebDriver driver) {
		driver.manage().deleteAllCookies();
	}

	public void close(WebDriver driver) {
		driver.close();
	}

	public void login(WebDriver driver) throws InterruptedException {
		PetsWorld_POM p = new PetsWorld_POM(driver);

		p.login();
		p.mobnum();
		p.cont();
		p.otp();
		p.otp1();
		p.verify();

		Thread.sleep(2000);

		/*
		 * driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(
		 * "Prachi");
		 * driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(
		 * "Singh");
		 * driver.findElement(By.xpath("//input[@placeholder='Email Address']")).
		 * sendKeys("myselfparachi@gmail.com");
		 * driver.findElement(By.xpath("//input[@placeholder='Phone Number (+91)']")).
		 * sendKeys("9654338769"); driver.findElement(By.
		 * xpath("//div[@class='flex-1 flex items-center justify-center']")).click();
		 */
	}

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = null;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter 1 for Google Chrome\nEnter 2 for MS_edge\nEnter 3 for MozillaFirefox");
		int input = s.nextInt();
		switch (input) {

		case 1:
			System.out.println("**Google Chrome**");
		//	System.setProperty("webdriver.chrome.driver","C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
		case 2:
			System.out.println("**MS_edge**");
			//System.setProperty("webdriver.msedge.driver","C:\\Users\\Kunal\\Documents\\Automation\\Browser Extension\\msedgedriver.exe");
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		case 3:
			System.out.println("**Firfox**");
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;

		default:
			System.out.println("Invalid Input");
		}

		Cross_Browser_Testing cb = new Cross_Browser_Testing();

		cb.url(driver);
		cb.maximize(driver);
		Thread.sleep(2000);
		// cb.login(driver);
		cb.close(driver);

	}

}
