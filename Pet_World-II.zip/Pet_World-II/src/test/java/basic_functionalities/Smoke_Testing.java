package basic_functionalities;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorld_POM;

public class Smoke_Testing {

	public void url(WebDriver driver) {
		driver.get("https://petsworld.in/");
	}

	public void maximize(WebDriver driver) {
		driver.manage().window().maximize();
	}

	public void cookies(WebDriver driver) {
		driver.manage().deleteAllCookies();
	}

	public void login(WebDriver driver) throws InterruptedException {
		PetsWorld_POM p = new PetsWorld_POM(driver);

		p.login();
		p.mobnum();
		p.cont();
		p.otp();
		p.otp1();
		p.verify();

	}

	public void logout(WebDriver driver) {
		WebElement myaccount = driver.findElement(By.linkText("My Account"));
		WebElement lo = driver.findElement(By.linkText(" Logout"));
		Actions a1 = new Actions(driver);
		a1.moveToElement(myaccount).perform();
		a1.click(lo).perform();

	}

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		Smoke_Testing sb = new Smoke_Testing();
		sb.url(driver);
		sb.maximize(driver);
		sb.login(driver);

		Actions a = new Actions(driver);

		List<WebElement> ls = driver.findElements(By.xpath("//ul[@class='list-none h-full flex']/li"));

		for (int i = 1; i <= 3; i++) {
			Thread.sleep(2000);
			System.out.println(
					driver.findElement(By.xpath("//ul[@class='list-none h-full flex']/li[" + i + "]")).getText());

			a.moveToElement(driver.findElement(By.xpath("//ul[@class='list-none h-full flex']/li[" + i + "]")))
					.perform();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='Shop by Pet']")).click();
		List<WebElement> ls1 = driver.findElements(By.xpath(
				"//ul[@class='flex flex-col min-h-[500px] overflow-scroll w-48 bg-secondary rounded-bl-lg']/li"));
		for (int i = 1; i <= 5; i++) {
			Thread.sleep(2000);
			System.out.println(driver.findElement(By.xpath(
					"//ul[@class='flex flex-col min-h-[500px] overflow-scroll w-48 bg-secondary rounded-bl-lg']/li[" + i
							+ "]"))
					.getText());
			Thread.sleep(2000);
			a.moveToElement(driver.findElement(By.xpath(
					"//ul[@class='flex flex-col min-h-[500px] overflow-scroll w-48 bg-secondary rounded-bl-lg']/li[" + i
							+ "]")))
					.perform();
		}

	}

}
