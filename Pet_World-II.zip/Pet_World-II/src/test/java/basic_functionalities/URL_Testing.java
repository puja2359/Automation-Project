package basic_functionalities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class URL_Testing 
{
	static WebDriver driver;
	String userurl="https://petsworld.in/";
	public void url(WebDriver driver)
	{
		
		driver.get(userurl);
	}
	public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
	public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
	public void urltest()
	{
		String actualurl=driver.getCurrentUrl();
		System.out.println("Current url" +actualurl);
		//Assert.assertEquals(actualurl,"https://petsworld.in/", "URL TEST IS SUCCESSFUL");
		if(actualurl.equals(userurl))
		{
			System.out.println("URL Testing passed");
		}else
		{
		System.out.println("URL testing failed");
		}
	}

	public static void main(String[] args) 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		
		URL_Testing url=new URL_Testing();
		url.url(driver);
		url.maximize(driver);
		url.cookies(driver);
		url.urltest();
		
	}

}
