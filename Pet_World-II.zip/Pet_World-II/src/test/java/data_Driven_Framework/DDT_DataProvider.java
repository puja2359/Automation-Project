package data_Driven_Framework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorldMyAccount_POM;
import pom.PetsWorld_POM;

public class DDT_DataProvider
{
	WebDriver driver;

	@BeforeMethod
	public void beforeTest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}

	@Test(dataProvider = "testdata")
	public void login(String mob) throws Exception {

		PetsWorld_POM p = new PetsWorld_POM(driver);

		p.login();
		driver.findElement(By.xpath("//input[@placeholder='Mobile Number / Email']")).sendKeys(mob);
		p.cont();
		p.otp();
		p.otp1();
		p.verify();
		Thread.sleep(4000);
		PetsWorldMyAccount_POM p2 = new PetsWorldMyAccount_POM(driver);
		p2.logout1();
		Thread.sleep(2000);
	}	
	@DataProvider(name = "testdata")
	public Object[][] tdata() 
	{
		return new Object[][] { { "7022609370" }, { "67543" }, { "7022609370" }, { "98654332" } };
	}	
	@AfterMethod
	public void close() 
	{
		driver.close();
		System.out.println("ddt successfull");
	}
}

