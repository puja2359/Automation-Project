package data_Driven_Framework;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JOptionPane;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorldMyAccount_POM;
import pom.PetsWorld_POM;

public class DDT_POI {

	public void url(WebDriver driver) {
		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}
	public static void main(String[] args) throws IOException, InterruptedException {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		FileInputStream file = new FileInputStream("C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\POI\\New_PetsWorld_POI.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet("Pets_DDT");

		int rowsize = sheet.getLastRowNum();
		System.out.println("No of Credential: " + rowsize);
		for (int r = 1; r <= rowsize; r++) 
		{
			XSSFRow row = sheet.getRow(r);

			XSSFCell cell = row.getCell(0);
			long mobile = (long) cell.getNumericCellValue();
			try // handle runtime error/exception bcz of invalid credential
			{
				DDT_POI p = new DDT_POI();
				p.url(driver);
				Thread.sleep(2000);
				PetsWorld_POM p1 = new PetsWorld_POM(driver);
				p1.login();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//input[@placeholder='Mobile Number / Email']"))
						.sendKeys(String.valueOf(mobile));

				p1.cont();
				Thread.sleep(2000);
				p1.otp();
				p1.otp1();
				p1.verify();
				Thread.sleep(4000);
				PetsWorldMyAccount_POM p2 = new PetsWorldMyAccount_POM(driver);
				p2.logout1();
				Thread.sleep(2000);
				driver.navigate().refresh();
				// update Test Result
				System.out.println("Valid Credential");
				System.out.println("");
				sheet.getRow(r).createCell(1).setCellValue("Valid Credential");
			} catch (Exception e) {
				// update Test Result
				e.getMessage();
				System.out.println("InValid Credential");
				System.out.println("");
				sheet.getRow(r).createCell(1).setCellValue("InValid Credential");
			}
			FileOutputStream out = new FileOutputStream("C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\POI\\New_PetsWorld_POI.xlsx");
			workbook.write(out);

		}
		file.close();
		workbook.close();
		driver.close();
     }
}
