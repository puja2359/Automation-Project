package pom;

import java.time.Duration;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PetsWorld_POM {
	WebDriver driver;

	@FindBy(linkText = "Login")
	WebElement login;
	@FindBy(xpath = "//input[@placeholder='Mobile Number / Email']")
	WebElement mobnum;
	@FindBy(xpath = "//div[@class='flex-1 flex items-center justify-center']")
	WebElement cont;
	@FindBy(xpath = "//div[text()='Login via OTP']")
	WebElement otp;
	@FindBy(xpath = "//div[@class='flex-1 flex items-center justify-center']")
	WebElement otp1;
	@FindBy(xpath = "//div[contains(text(),'Verify')]")
	WebElement verify;

	public PetsWorld_POM(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void login() {
		login.click();
	}

	public void mobnum() {
		mobnum.sendKeys("7022609370");
	}

	public void cont() {
		cont.click();
	}

	public void otp() throws InterruptedException {
		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(20));
	    WebElement otp= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Login via OTP']")));
		otp.click();
		Thread.sleep(2000);
	}

	public void otp1() throws InterruptedException {
	    String D1 = JOptionPane.showInputDialog("BOX 1");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[1]/div/section/div[2]/div[1]/div/div[1]/div[1]/input"))
				.sendKeys(D1);
		Thread.sleep(2000);
		String D2 = JOptionPane.showInputDialog("BOX 2");
		driver.findElement(By.xpath("//input[@aria-label='Digit 2']")).sendKeys(D2);
		Thread.sleep(2000);
		String D3 = JOptionPane.showInputDialog("BOX 3");
		driver.findElement(By.xpath("//input[@aria-label='Digit 3']")).sendKeys(D3);
		Thread.sleep(2000);
		String D4 = JOptionPane.showInputDialog("BOX 4");
		driver.findElement(By.xpath("//input[@aria-label='Digit 4']")).sendKeys(D4);
		Thread.sleep(2000);
		String D5 = JOptionPane.showInputDialog("BOX 5");
		driver.findElement(By.xpath("//input[@aria-label='Digit 5']")).sendKeys(D5);
		Thread.sleep(2000);
		String D6 = JOptionPane.showInputDialog("BOX 6");
		driver.findElement(By.xpath("//input[@aria-label='Digit 6']")).sendKeys(D6);
		Thread.sleep(2000);
	}

	public void verify() {
		verify.click();
	}
}
