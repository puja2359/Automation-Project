package pom;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PetsWorldMyAccount_POM {
	public WebDriver driver;
	@FindBy(xpath = "//span[normalize-space()='My Account']")
	WebElement myaccount;

	public PetsWorldMyAccount_POM(WebDriver driver2) {
		driver = driver2;
		PageFactory.initElements(driver2, this);
	}
	public void mypets() throws InterruptedException 
	{   
		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(20));
	    WebElement myaccount= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[3]/div[3]/a[1]/span[1]")));
		Actions a1 = new Actions(driver);
		a1.moveToElement(myaccount).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[@href='/dashboard/pets']")).click();
	}

	public void logout1() throws InterruptedException 
	{   
		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement myaccount= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[3]/div[3]/a[1]/span[1]")));
		Actions a1 = new Actions(driver);
		a1.moveToElement(myaccount).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[3]/div[3]/div[1]/ul[1]/li[3]")).click();
   }
}