package functional_testing;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.List;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorldMyAccount_POM;
import pom.PetsWorld_POM;

public class MyPets {
	WebDriver driver;

	@BeforeTest
	public void login() throws InterruptedException {
	//	System.setProperty("webdriver.chrome.driver","C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		PetsWorld_POM p = new PetsWorld_POM(driver);
		p.login();
		p.mobnum();
		p.cont();
		p.otp();
		p.otp1();
		p.verify();

		Thread.sleep(4000);

	}

	@Test
	public void mypets() throws InterruptedException, AWTException {
		PetsWorldMyAccount_POM p = new PetsWorldMyAccount_POM(driver);
		p.mypets();
		driver.findElement(By.xpath("//div[contains(@class,'md:flex items-center justify-between')]//div[@class='flex-1 flex items-center justify-center']")).click();
		Thread.sleep(2000);

		List<WebElement> pettype = driver
				.findElements(By.xpath("//li[@class='flex space-x-3 items-center border-b-1 py-5 cursor-pointer']"));
		try {
			List<WebElement> pettype1 = driver.findElements(
					By.xpath("//li[@class='flex space-x-3 items-center border-b-1 py-5 cursor-pointer']"));
			for (int i = 0; i <= pettype1.size(); i++) {

				if (pettype1.get(i).getText().contains("Dogs")) {
					pettype1.get(i).click();
				}
			}

		} catch (StaleElementReferenceException e) {
			System.out.println(e.getMessage());
		}
		Thread.sleep(2000);
		List<WebElement> breedtype = driver.findElements(By.xpath("//li[@class='flex space-x-3 items-center border-b-1 py-5 cursor-pointer']")); //Golden Retriever
		try {
			List<WebElement> breedtype1 = driver.findElements(
					By.xpath("//li[@class='flex space-x-3 items-center border-b-1 py-5 cursor-pointer']"));
			for (int i = 0; i <= breedtype1.size(); i++) {

				if (breedtype.get(i).getText().contains("Golden Retriever")) {
					breedtype.get(i).click();
				}
			}

		} catch (StaleElementReferenceException e) {
			System.out.println(e.getMessage());
		}
		Thread.sleep(2000);

		String petname = JOptionPane.showInputDialog("Enter Petname");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Pet Name']")).sendKeys(petname);
		Thread.sleep(2000);

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement upload = driver.findElement(By.id("review_image_upload"));

		// using robot class
		JavascriptExecutor js = ((JavascriptExecutor) driver); // for handling windows
		js.executeScript("arguments[0].click();", upload);

		Robot r = new Robot();
		r.setAutoDelay(2000);

		// if you want to store a path CTRL+C
		StringSelection s = new StringSelection("C:\\Users\\Admin Pc\\Downloads\\Dog.png");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);

		// if you want to store a path CTRL+V
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_V);

		r.keyRelease(KeyEvent.VK_CONTROL);
		r.keyRelease(KeyEvent.VK_V);

		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);

		String year = "2020";
		String month = "July";
		String date = "19";

		driver.findElement(By.xpath("//input[@placeholder='DD/MM/YYYY']")).sendKeys("19feb2020");

	}
	@AfterTest
	public void close() 
	{
		driver.close();
	}

}
