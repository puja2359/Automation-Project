package functional_testing;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorldMyAccount_POM;
import pom.PetsWorld_POM;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

@Test(groups = "user registration")
public class Login {
	WebDriver driver;

	@BeforeTest
	public void beforeTest() {
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}

	@Test(priority = 1)
	public void toCheckTheFunctionalityOfLoginWithValidData() throws Exception {

		PetsWorld_POM p = new PetsWorld_POM(driver);

		p.login();
		p.mobnum();
		p.cont();
		p.otp();
		p.otp1();
		p.verify();
		Thread.sleep(2000);
	}

	@Test(priority = 2)
	public void toCheckTheFunctionalityOfLoginWithValidDataViaWhatsapp() throws Exception {
		PetsWorldMyAccount_POM p1 = new PetsWorldMyAccount_POM(driver);
		p1.logout1();
		Thread.sleep(2000);

		PetsWorld_POM p = new PetsWorld_POM(driver);
		p.login();
		p.mobnum();
		p.cont();
		driver.findElement(By.xpath("//span[text()='OTP via WhatsApp']")).click();
		String D1 = JOptionPane.showInputDialog("BOX 1");
		Thread.sleep(2000);
		driver.findElement(
				By.xpath("/html[1]/body[1]/div[1]/div[1]/section[1]/div[2]/div[1]/div[1]/div[1]/div[1]/input[1]"))
				.sendKeys(D1);
		Thread.sleep(2000);
		String D2 = JOptionPane.showInputDialog("BOX 2");
		driver.findElement(By.xpath("//input[@aria-label='Digit 2']")).sendKeys(D2);
		Thread.sleep(2000);
		String D3 = JOptionPane.showInputDialog("BOX 3");
		driver.findElement(By.xpath("//input[@aria-label='Digit 3']")).sendKeys(D3);
		Thread.sleep(2000);
		String D4 = JOptionPane.showInputDialog("BOX 4");
		driver.findElement(By.xpath("//input[@aria-label='Digit 4']")).sendKeys(D4);
		Thread.sleep(2000);
		String D5 = JOptionPane.showInputDialog("BOX 5");
		driver.findElement(By.xpath("//input[@aria-label='Digit 5']")).sendKeys(D5);
		Thread.sleep(2000);
		String D6 = JOptionPane.showInputDialog("BOX 6");
		driver.findElement(By.xpath("//input[@aria-label='Digit 6']")).sendKeys(D6);
		Thread.sleep(2000);
		p.verify();
	}

	@Test(priority = 3)
	public void toCheckTheFunctionalityOfLoginWithInValidData() throws Exception

	{
		Thread.sleep(4000);
		PetsWorldMyAccount_POM p1 = new PetsWorldMyAccount_POM(driver);
		p1.logout1();
		Thread.sleep(2000);
		PetsWorld_POM p = new PetsWorld_POM(driver);
		p.login();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Mobile Number / Email']")).sendKeys("ravikant9693");
		p.cont();
		Thread.sleep(2000);
		System.out.println("Email / Phone is invalid");
	}

	@Test(priority = 4)
	public void tocheckthefunctionalitywithemptydata() throws InterruptedException {
		Thread.sleep(4000);
		driver.get("https://petsworld.in/");
		Thread.sleep(2000);
		PetsWorld_POM p = new PetsWorld_POM(driver);
		p.login();
		driver.findElement(By.xpath("//input[@placeholder='Mobile Number / Email']")).sendKeys(" ");
		p.cont();
		Thread.sleep(2000);
		System.out.println("Email / Phone is invalid");

	}

	@AfterTest
	public void closebrowser() {
		driver.close();
	}

}
