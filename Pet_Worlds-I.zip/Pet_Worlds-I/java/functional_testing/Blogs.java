package functional_testing;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorld_POM;

public class Blogs {
	WebDriver driver;

	@BeforeTest
	public void before() throws InterruptedException 
	{
        WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}
	@Test
	public void showall() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,4200)");
		Thread.sleep(2000);

		driver.findElement(By.xpath("//a[@href='https://petsworld.in/blog']")).click();

		String pid = driver.getWindowHandle();
		Thread.sleep(2000);
		System.out.println(pid);

		Set<String> cid = driver.getWindowHandles();
		System.out.println(cid);

		for (String windowhandle : cid) {
			if (!windowhandle.equals(pid)) {
				driver.switchTo().window(windowhandle);
				js.executeScript("window.scrollBy(0,1500)");
				Thread.sleep(2000);
				File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

				try {
					FileUtils.copyFile(screenshot, new File("C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\eclipse backup\\Pet_World\\src\\test\\resources\\Blogs.png"));
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
				Thread.sleep(2000);
				driver.findElement(
						By.xpath("/html[1]/body[1]/div[1]/section[1]/article[1]/div[1]/div[1]/ul[1]/li[2]/a[1]"))
						.click();
				Thread.sleep(2000);
				driver.navigate().back();
			}
		}
	}
	@AfterTest
	public void closebrowser() 
	{
		driver.close();
	}
}
