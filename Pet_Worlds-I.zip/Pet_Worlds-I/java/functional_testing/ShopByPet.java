package functional_testing;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ShopByPet 
{
	WebDriver driver;

	@BeforeTest
	public void beforeTest() 
	{
	//	System.setProperty("webdriver.chrome.driver","C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}

	@Test(priority = 1)
	public void shopbydog() throws InterruptedException 
	{
		driver.findElement(By.xpath("//img[@alt='Dogs']")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver; // scroll upto 300
		js.executeScript("window.scrollBy(0,300)");
		driver.findElement(By.xpath("//a[@href='/dog-clothing/c/705ZIE']")).click();
		js.executeScript("window.scrollBy(0,800)");
		Thread.sleep(2000);
		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(screenshot, new File(
					"C:\\Users\\Kunal\\Documents\\Automation\\Eclipse Backup\\Pet_World\\src\\test\\resources\\Screenshot\\shopbypetScreenshot.png"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		Thread.sleep(4000);

	}

	@Test(priority = 2)
	public void shopcats() 
	{
		driver.findElement(By.xpath("//img[@alt='Cats']")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver; // scroll upto 300
		js.executeScript("window.scrollBy(0,300)");
		driver.findElement(By.xpath("//a[@href='/cat-furniture-and-scratchers/c/IQ2VTL']")).click();

	}

	@Test(priority = 3)
	public void shopbirds() 
	{
		driver.findElement(By.xpath("//img[@alt='Birds']")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver; // scroll upto 300
		js.executeScript("window.scrollBy(0,300)");
		driver.findElement(By.xpath("//a[@href='/vitamins-and-minerals/c/A8CPSW']")).click();
	}

	@Test(priority = 4)
	public void shopfishes() 
	{
		driver.findElement(By.xpath("//img[@alt='Fishes']")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver; // scroll upto 300
		js.executeScript("window.scrollBy(0,300)");
		driver.findElement(By.xpath("//a[@href='/aquarium-accessories/c/XGXTN9']")).click();

	}

	@Test(priority = 5)
	public void shopsmallpets() 
	{
		driver.findElement(By.xpath("//img[@alt='Small Pets']")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver; // scroll upto 300
		js.executeScript("window.scrollBy(0,300)");
		driver.findElement(By.xpath("//a[@href='/food/c/C3IFBP']")).click();

	}

	@AfterMethod
	public void home() 
	{
		driver.findElement(By.xpath("//div[@class='bg-contain bg-no-repeat h-10 md:h-14 bg-left']")).click();
	}

	@AfterTest
	public void close() 
	{
		driver.close();
	}

}
