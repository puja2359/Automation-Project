package functional_testing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorldMyAccount_POM;
import pom.PetsWorld_POM;

public class Logoutuser {
	WebDriver driver;

	@BeforeTest
	public void login() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

	}

	@Test
	public void logout() throws InterruptedException {
		PetsWorld_POM p = new PetsWorld_POM(driver);
		p.login();
		p.mobnum();
		p.cont();
		p.otp();
		p.otp1();
		p.verify();
		Thread.sleep(4000);

		PetsWorldMyAccount_POM p1 = new PetsWorldMyAccount_POM(driver);
		p1.logout1();

	}

	@AfterTest
	public void closebrowser() {
		driver.close();
	}

}
