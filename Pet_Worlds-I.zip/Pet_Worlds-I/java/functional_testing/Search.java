
package functional_testing;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Search {

	WebDriver driver;

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

	}

	@Test(priority = 1)
	public void toCheckTheFunctionalityOfSearchModuleWithValidData() throws Exception {

		List<WebElement> search = driver.findElements(By.xpath(
				"//li[@class='sc-gsDKAQ gEVjfD px-3 ml-5 py-3 hover:bg-gray-50 cursor-pointer border-b-1 border-b-gray-100 flex items-center justify-between']"));

		String Search = JOptionPane.showInputDialog("Search for PetsWorlds");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]"))
				.sendKeys(Search);
		Thread.sleep(5000);

		try {
			List<WebElement> search1 = driver.findElements(By.xpath(
					"//li[@class='sc-gsDKAQ gEVjfD px-3 ml-5 py-3 hover:bg-gray-50 cursor-pointer border-b-1 border-b-gray-100 flex items-center justify-between']"));
			for (int i = 0; i <= search1.size(); i++) {

				if (search1.get(i).getText().contains("Inaba")) {
					search1.get(i).click();
				}
			}
		} catch (StaleElementReferenceException e) {
			System.out.println(e.getMessage());
		}
		JavascriptExecutor js = (JavascriptExecutor) driver; // scroll upto 300
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//a[@href='/inaba-churu-chicken-with-salmon-recipe-cat-treat-56-g/d/A000582104']")));
		List<WebElement> search2 = driver.findElements(By.xpath(
				"//article[@class='x-min-h-[350px] w-full md:max-w-[320px] group cursor-pointer flex space-x-2 md:space-x-0 flex-row md:flex-col relative ']"));

		try {
			List<WebElement> search1 = driver.findElements(By.xpath(
					"//article[@class='x-min-h-[350px] w-full md:max-w-[320px] group cursor-pointer flex space-x-2 md:space-x-0 flex-row md:flex-col relative ']"));
			for (int i = 0; i <= search1.size(); i++) {

				if (search1.get(i).getText().contains("Inaba Churu Chicken With Salmon Recipe Cat Treat 56g")) {
					search1.get(i).click();
				}
			}
		} catch (IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		String pid = driver.getWindowHandle();
		Thread.sleep(2000);
		System.out.println(pid);

		Set<String> cid = driver.getWindowHandles();
		System.out.println(cid);

		for (String windowhandle : cid) {
			if (!windowhandle.equals(pid)) {
				driver.switchTo().window(windowhandle);
				JavascriptExecutor js1 = (JavascriptExecutor) driver; // scroll upto 300
				js1.executeScript("window.scrollBy(0,500)");
				Thread.sleep(2000);

				driver.findElement(By.xpath("//div[text()='Add to cart']")).click();
				Thread.sleep(2000);
				js1.executeScript("window.scrollBy(0,-500)");
			}
		}
	}

	@Test(priority = 2)
	public void toCheckTheFunctionalityOfSearchModuleWithInValidData() throws InterruptedException {

		driver.findElement(By.xpath("//div[@class='bg-contain bg-no-repeat h-10 md:h-14 bg-left']")).click(); // petsworld
																												// logo
		Thread.sleep(2000);
		String Search = JOptionPane.showInputDialog("Search for PetsWorlds");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]"))
				.sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		//System.out.println("Ooppss! Not found!");
	}

	@Test(priority = 3)
	public void toCheckTheFunctionalityOfSearchModuleWithEmptyData() throws Exception {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='bg-contain bg-no-repeat h-10 md:h-14 bg-left']")).click(); // petsworld
																												// logo
		String Search = JOptionPane.showInputDialog("Search for PetsWorlds");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]"))
				.sendKeys(Search);
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]"))
				.sendKeys(Keys.ENTER);
	}

	@AfterTest
	public void close() 
	{
		driver.close();
	}
}
