package functional_testing;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PetsWorld_POM;

public class Cart {
	WebDriver driver;

	@BeforeTest
	public void beforeTest() throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.get("https://petsworld.in/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.manage().deleteAllCookies();
		PetsWorld_POM p = new PetsWorld_POM(driver);
		p.login();
		p.mobnum();
		p.cont();
		p.otp();
		p.otp1();
		p.verify();

		Thread.sleep(4000);

	}

	@Test
	public void addtocart() throws Exception {
		List<WebElement> search = driver.findElements(By.xpath(
				"//li[@class='sc-gsDKAQ gEVjfD px-3 ml-5 py-3 hover:bg-gray-50 cursor-pointer border-b-1 border-b-gray-100 flex items-center justify-between']"));

		String Search = JOptionPane.showInputDialog("Search for PetsWorlds");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]"))
				.sendKeys(Search);
		Thread.sleep(5000);

		try {
			List<WebElement> search1 = driver.findElements(By.xpath(
					"//li[@class='sc-gsDKAQ gEVjfD px-3 ml-5 py-3 hover:bg-gray-50 cursor-pointer border-b-1 border-b-gray-100 flex items-center justify-between']"));
			for (int i = 0; i <= search1.size(); i++) {

				if (search1.get(i).getText().contains("Inaba")) {
					search1.get(i).click();

				}

			}

		} catch (StaleElementReferenceException e) {
			System.out.println(e.getMessage());
		}
		JavascriptExecutor js = (JavascriptExecutor) driver; // scroll upto 300
		js.executeScript("window.scrollBy(0,1500)");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(7));
		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//a[@href='/inaba-churu-chicken-with-salmon-recipe-cat-treat-56-g/d/A000582104']")));
		List<WebElement> search2 = driver.findElements(By.xpath(
				"//article[@class='x-min-h-[350px] w-full md:max-w-[320px] group cursor-pointer flex space-x-2 md:space-x-0 flex-row md:flex-col relative ']"));

		try {
			List<WebElement> search1 = driver.findElements(By.xpath(
					"//article[@class='x-min-h-[350px] w-full md:max-w-[320px] group cursor-pointer flex space-x-2 md:space-x-0 flex-row md:flex-col relative ']"));
			for (int i = 0; i <= search1.size(); i++) {

				if (search1.get(i).getText().contains("Inaba Churu Chicken With Salmon Recipe Cat Treat 56g")) {
					search1.get(i).click();

				}

			}

		} catch (IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		String pid = driver.getWindowHandle();
		Thread.sleep(2000);
		System.out.println(pid);

		Set<String> cid = driver.getWindowHandles();
		System.out.println(cid);

		for (String windowhandle : cid) {
			if (!windowhandle.equals(pid)) {

				driver.switchTo().window(windowhandle);
				JavascriptExecutor js1 = (JavascriptExecutor) driver; // scroll upto 300
				js1.executeScript("window.scrollBy(0,500)");
				Thread.sleep(2000);

				driver.findElement(By.xpath("//div[text()='Add to cart']")).click();
				Thread.sleep(2000);
				js1.executeScript("window.scrollBy(0,-500)");

			}
		}

		driver.findElement(By.xpath("//a[@href='/cart']")).click();
		Thread.sleep(2000);

		Thread.sleep(2000);
		driver.findElement(
				By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]/div[1]/div[1]")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//div[@id='headlessui-portal-root']//p[1]")).click(); // 2nd time to select address
		Thread.sleep(4000);
		driver.findElement(By.xpath(
				"//button[@class='h-full lg:h-14 w-24 max-w-sm lg:w-full border-1 flex-1 bg-primary hover:bg-primary-hover rounded-md text-white text-xs flex justify-between items-center p-2.5']"))
				.click();
		Thread.sleep(2000);

		Thread.sleep(4000);

		int size = driver.findElements(By.tagName("iframe")).size();
		System.out.println("Total Frames --" + size);

		WebDriver a = driver.switchTo().frame(1);
		a.getTitle();

		List<WebElement> payment = driver
				.findElements(By.xpath("//button[@class='new-method has-tooltip false svelte-1d17g67']"));
		try {
			List<WebElement> payment1 = driver
					.findElements(By.xpath("//button[@class='new-method has-tooltip false svelte-1d17g67']"));
			for (int i = 0; i <= payment1.size(); i++) {

				if (payment1.get(i).getText().contains("Card")) {

					payment1.get(i).click();
				}
			}
		}

		catch (IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		String entercard = JOptionPane.showInputDialog("card number");
		Thread.sleep(2000);
		driver.findElement(By.id("card_number")).sendKeys(entercard);

		String expiry = JOptionPane.showInputDialog("Expiry");
		Thread.sleep(2000);
		driver.findElement(By.id("card_expiry")).sendKeys(expiry);

		String cvv = JOptionPane.showInputDialog("CVV");
		Thread.sleep(2000);
		driver.findElement(By.id("card_cvv")).sendKeys(cvv);
		Thread.sleep(2000);
		driver.findElement(By.id("redesign-v15-cta")).click();
	}

	@AfterTest
	public void closebrowser() {
		// driver.close();
	}
}
